package factorymethod;

public abstract class CoffeeMachine {

    protected abstract Drink createDrink();

    public String serve() {
        Drink drink = createDrink();
        return "[Machine] " + drink.prepare() + " -> " + drink.describe();
    }
}