package factorymethod;

public class EspressoMachine extends CoffeeMachine {
    @Override
    protected Drink createDrink() {
        return new Espresso();
    }
}