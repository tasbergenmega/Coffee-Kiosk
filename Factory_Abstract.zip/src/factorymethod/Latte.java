package factorymethod;

public class Latte implements Drink {
    @Override
    public String prepare() {
        return "Latte: 18g coffee + 200ml steamed milk + foam";
    }

    @Override
    public String describe() {
        return "Mild milky coffee";
    }
}