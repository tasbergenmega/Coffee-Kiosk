package factorymethod;

public class Cappuccino implements Drink {
    @Override
    public String prepare() {
        return "Cappuccino: 18g coffee + 120ml milk + thick foam";
    }

    @Override
    public String describe() {
        return "Balanced coffee with dense foam";
    }
}