package factorymethod;

public interface Drink {
    String prepare();
    String describe();
}