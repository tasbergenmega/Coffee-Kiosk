package factorymethod;

public class Main {
    public static void main(String[] args) {
        CoffeeMachine machine = pickMachine("espresso");
        System.out.println(machine.serve());

        machine = pickMachine("latte");
        System.out.println(machine.serve());

        machine = pickMachine("cappuccino");
        System.out.println(machine.serve());
    }

    private static CoffeeMachine pickMachine(String drink) {
        return switch (drink) {
            case "espresso"   -> new EspressoMachine();
            case "latte"      -> new LatteMachine();
            case "cappuccino" -> new CappuccinoMachine();
            default -> throw new IllegalArgumentException("Unknown drink: " + drink);
        };
    }
}