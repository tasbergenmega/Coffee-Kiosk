package factorymethod;

public class LatteMachine extends CoffeeMachine {
    @Override
    protected Drink createDrink() {
        return new Latte();
    }
}