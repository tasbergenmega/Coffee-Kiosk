package factorymethod;

public class CappuccinoMachine extends CoffeeMachine {
    @Override
    protected Drink createDrink() {
        return new Cappuccino();
    }
}