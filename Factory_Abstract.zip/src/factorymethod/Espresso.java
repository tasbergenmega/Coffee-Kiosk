package factorymethod;

public class Espresso implements Drink {
    @Override
    public String prepare() {
        return "Espresso: 18g coffee, 25s extraction, 30ml in cup";
    }

    @Override
    public String describe() {
        return "Strong Italian shot";
    }
}