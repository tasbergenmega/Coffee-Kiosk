package abstractfactory;

public class EcoLid implements Lid {
    @Override
    public String type() {
        return "compostable fiber lid";
    }

    @Override
    public boolean fits(Cup cup) {
        return cup.material().equals("recycled cardboard") && cup.volumeMl() == 250;
    }
}