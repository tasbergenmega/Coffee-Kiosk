package abstractfactory;

public class EcoReceipt implements Receipt {
    @Override
    public String print(String drinkName, double price) {
        return String.format("~~ ECO BREW ~~%n%s ... %.2f EUR%nSave the planet!",
                drinkName, price);
    }
}