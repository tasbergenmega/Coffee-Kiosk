package abstractfactory;

public class Main {
    public static void main(String[] args) {
        CoffeeSetFactory factory = pickBrand("classic");

        CoffeeKiosk kiosk = new CoffeeKiosk(factory);
        System.out.println(kiosk.serve("Latte", 3.50));
        System.out.println();

        kiosk = new CoffeeKiosk(pickBrand("eco"));
        System.out.println(kiosk.serve("Espresso", 2.20));
    }

    private static CoffeeSetFactory pickBrand(String brand) {
        return switch (brand) {
            case "classic" -> new ClassicSetFactory();
            case "eco"     -> new EcoSetFactory();
            default -> throw new IllegalArgumentException("Unknown brand: " + brand);
        };
    }
}