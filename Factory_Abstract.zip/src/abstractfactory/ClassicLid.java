package abstractfactory;

public class ClassicLid implements Lid {
    @Override
    public String type() {
        return "flat plastic lid";
    }

    @Override
    public boolean fits(Cup cup) {
        return cup.material().equals("paper") && cup.volumeMl() == 300;
    }
}