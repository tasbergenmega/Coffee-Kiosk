package abstractfactory;

public interface CoffeeSetFactory {
    Cup createCup();
    Lid createLid();
    Receipt createReceipt();
}