package abstractfactory;

public interface Receipt {
    String print(String drinkName, double price);
}
