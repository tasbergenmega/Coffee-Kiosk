package abstractfactory;

public class ClassicReceipt implements Receipt {
    @Override
    public String print(String drinkName, double price) {
        return String.format("== CLASSIC COFFEE ==%n%s ... %.2f EUR%nThank you!",
                drinkName, price);
    }
}