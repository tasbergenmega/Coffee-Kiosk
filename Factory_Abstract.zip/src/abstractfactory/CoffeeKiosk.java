package abstractfactory;

public class CoffeeKiosk {

    private final CoffeeSetFactory factory;   // composition, not inheritance

    public CoffeeKiosk(CoffeeSetFactory factory) {
        this.factory = factory;
    }

    public String serve(String drinkName, double price) {
        Cup cup = factory.createCup();
        Lid lid = factory.createLid();
        Receipt receipt = factory.createReceipt();

        if (!lid.fits(cup)) {
            return "ERROR: lid does not fit cup — inconsistent family!";
        }

        return String.format("Serving %s in %s cup (%d ml) with %s%n%s",
                drinkName, cup.material(), cup.volumeMl(), lid.type(),
                receipt.print(drinkName, price));
    }
}