package abstractfactory;

public class EcoCup implements Cup {
    @Override
    public String material() {
        return "recycled cardboard";
    }

    @Override
    public int volumeMl() {
        return 250;
    }
}