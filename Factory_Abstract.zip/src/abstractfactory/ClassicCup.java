package abstractfactory;

public class ClassicCup implements Cup {
    @Override
    public String material() {
        return "paper";
    }

    @Override
    public int volumeMl() {
        return 300;
    }
}