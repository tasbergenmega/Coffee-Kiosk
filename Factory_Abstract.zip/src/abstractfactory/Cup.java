package abstractfactory;

public interface Cup {
    String material();
    int volumeMl();
}