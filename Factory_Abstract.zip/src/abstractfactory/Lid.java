package abstractfactory;

public interface Lid {
    String type();
    boolean fits(Cup cup);
}