package abstractfactory;

public class ClassicSetFactory implements CoffeeSetFactory {
    @Override
    public Cup createCup() {
        return new ClassicCup();
    }

    @Override
    public Lid createLid() {
        return new ClassicLid();
    }

    @Override
    public Receipt createReceipt() {
        return new ClassicReceipt();
    }
}